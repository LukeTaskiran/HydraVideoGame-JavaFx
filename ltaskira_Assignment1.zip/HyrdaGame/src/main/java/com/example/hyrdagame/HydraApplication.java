package com.example.hyrdagame;

import javafx.application.Application;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.image.Image;
import javafx.scene.layout.Pane;
import javafx.scene.paint.Color;
import javafx.stage.Stage;

import java.io.IOException;

public class HydraApplication extends Application {


    @Override
    public void start(Stage stage) throws IOException {

        FXMLLoader fxmlLoader = new FXMLLoader(HydraApplication.class.getResource("HydraView.fxml"));

        Scene scene = new Scene(fxmlLoader.load(), 800, 850); //set window size to 800 * 850
        stage.setTitle("Hydra Game"); //change window title to Hydra Game
        Image icon = new Image("file:src/main/resources/com/example/hyrdagame/HydraIcon.png"); //set icon window title to hydra icon
        stage.getIcons().add(icon); //shows hydra icon

        stage.setScene(scene);
        stage.show();

    }

    public static void main(String[] args) {
        launch();
    }
}