package com.example.hyrdagame;

import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.Slider;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.Pane;

import java.net.URL;
import java.security.cert.PolicyNode;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Random;
import java.util.ResourceBundle;
//Luke Taskiran 251179088 Feb 9 2022
public class HydraController implements Initializable {

    public int count; //count for every head clicked


   public Image hydra1 = new Image("file:src/main/resources/com/example/hyrdagame/HeadSize1.png"); //universal image of hydra head 1
    public Image hydra2 = new Image("file:src/main/resources/com/example/hyrdagame/HeadSize2.png");//universal image of hydra head 2
    public Image hydra3 = new Image("file:src/main/resources/com/example/hyrdagame/HeadSize3.png");//universal image of hydra head 3
    public Image hydra4 = new Image("file:src/main/resources/com/example/hyrdagame/HeadSize4.png");//universal image of hydra head 4
    public Image hydra5 = new Image("file:src/main/resources/com/example/hyrdagame/HeadSize5.png");//universal image of hydra head 5
    public Image hydra6 = new Image("file:src/main/resources/com/example/hyrdagame/HeadSize6.png");//universal image of hydra head 6

    @FXML
    private Pane playingField; //playing area where hydra heads are spawned
    @FXML
    private Label WonLabel; //label that shows when all heads are clicked
    @FXML
    private Button resetButton; //reset button for game
    @FXML
    private Button playButton; //play button for starting spawning heads
    @FXML
    private Slider slider; //slider for setting hydra head levels
    @FXML
    private Pane pane; //main pane with playingField, buttons, and slider
    private ArrayList<Integer> ArrayX = new ArrayList<>(); //arraylist for x coordinates of hydra heads
    private ArrayList<Integer> ArrayY = new ArrayList<>(); //arraylist for y coordinates of hydra heads
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        pane.setStyle("-fx-background-color: #FFFFFF"); //sets main pane to pure white
        slider.setDisable(false); //activate slider
        playButton.setDisable(false); //activate play button
        WonLabel.setDisable(true); //hide won label

    }

    public void playFunction() { //function for when play button is clicked
        playButton.setDisable(true); //disable play button
        slider.setDisable(true); //disable slider



    if (slider.getValue() == 2) { //if slider is set to 2 and play button is pressed call Head Size 2 method
        HeadSize2();
    } else if (slider.getValue() == 3) { //if slider is set to 3 and play button is pressed call Head Size 3 method
        HeadSize3();


    } else if (slider.getValue() == 4) { //if slider is set to 4 and play button is pressed call Head Size 4 method
        HeadSize4();

    } else if (slider.getValue() == 5) { //if slider is set to 5 and play button is pressed call Head Size 5 method
        HeadSize5();

    } else { //if slider is set to 6 and play button is pressed call Head Size 6 method
        HeadSize6();

    }
        }



    public void HeadSize1(){

        Random randomPos = new Random(); //random called for x and y coordinates
        ImageView One = new ImageView(hydra1); //set an ImageView to hydra one image
        One.setFitHeight(40);
        One.setFitWidth(40); //sets hydra image size to 40 x 40
        One.setLayoutX(randomPos.nextInt(780)); //generates imageview randomly on x axis from 0 - 780
        int resultx = (int)One.getLayoutX(); //retrieve x coordinate produce for checking overlaps

        One.setLayoutY(randomPos.nextInt(650)); //generates imageview randomly on y axis from 0 - 650
        int resulty = (int)One.getLayoutY(); //retrieve y coordinate produce for checking overlaps

        if(ArrayX.contains(resultx) && ArrayY.contains(resulty)){ // if x and y coordinate are exact to another imageview
            resultx *= 0.5;
            resulty *= 0.5; //moves x and y coordinate of imageview
        }
        ArrayX.add(Integer.valueOf(resultx)); //adds to data structure of X
        ArrayY.add(Integer.valueOf(resulty)); //adds to data structure of Y
        int finalResultx = resultx;
        int finalResulty = resulty;
        One.setOnMouseClicked(new EventHandler<MouseEvent>() { // when image is clicked
            @Override
            public void handle(MouseEvent t) {


                playingField.getChildren().remove(One); //remove from playing area
                ArrayX.remove(ArrayX.indexOf(finalResultx)); //remove x coordinates because it is removed
                ArrayY.remove(ArrayY.indexOf(finalResulty));//remove y coordinates because it is removed
                count += 1; //increase count


            }
        });


        playingField.getChildren().add(One); //add Image View



    }
    public void gamechecker(){ //checks once game is over
        if(playingField.getChildren().size() == 1){ //fxml has wonLabel on there so when all heads are clicked only label is left therefore empty

            WonLabel.setText("You cut "+ count + " hydraheads!!! NICE"); //show winning count
            WonLabel.setDisable(false); //show wonLabel
        }
    }
    public void HeadSize2(){

        Random randomPos = new Random();//random called for x and y coordinates
        ImageView Two = new ImageView(hydra2);//set an ImageView to hydra two image
        Two.setFitHeight(40);
        Two.setFitWidth(40);//sets hydra image size to 40 x 40
        Two.setLayoutX(randomPos.nextInt(760));//generates imageview randomly on x axis from 0 - 780
        int resultx = (int)Two.getLayoutX();//retrieve x coordinate produce for checking overlaps

        Two.setLayoutY(randomPos.nextInt(650));//generates imageview randomly on y axis from 0 - 650
        int resulty = (int)Two.getLayoutY();//retrieve y coordinate produce for checking overlaps

        Random random = new Random();
        int result = random.nextInt(2) + 2;//creates random number from 2-3 for declaring new spawned imageViews
        if(ArrayX.contains(resultx) && ArrayY.contains(resulty)){// if x and y coordinate are exact to another imageview
            resultx *= 0.5;
            resulty *= 0.5;//moves x and y coordinate of imageview
        }
        ArrayX.add(Integer.valueOf(resultx)); //adds to data structure of X
        ArrayY.add(Integer.valueOf(resulty)); //adds to data structure of Y
        int finalResultx = resultx;
        int finalResulty = resulty;
        Two.setOnMouseClicked(new EventHandler<MouseEvent>() {// when image is clicked

            @Override
            public void handle(MouseEvent t) {

                playingField.getChildren().remove(Two);//remove from playing area
                ArrayX.remove(ArrayX.indexOf(finalResultx)); //remove x coordinates because it is removed
                ArrayY.remove(ArrayY.indexOf(finalResulty));//remove y coordinates because it is removed
                count += 1;//increase count
                for(int i = 0; i < result; i++){//recursive call of n-1 hydra head which spawns random 2-3 range for loop

                    HeadSize1();
                }
            }
        });

        playingField.getChildren().add(Two);//add Image View
    }
    public void HeadSize3(){
        Random randomPos = new Random();//random called for x and y coordinates
        ImageView Three = new ImageView(hydra3);//set an ImageView to hydra three image
        Three.setFitHeight(40);
        Three.setFitWidth(40);//sets hydra image size to 40 x 40
        Three.setLayoutX(randomPos.nextInt(760));//generates imageview randomly on x axis from 0 - 780
        int resultx = (int)Three.getLayoutX();//retrieve x coordinate produce for checking overlaps

        Three.setLayoutY(randomPos.nextInt(650));//generates imageview randomly on y axis from 0 - 650
        int resulty = (int)Three.getLayoutY();//retrieve y coordinate produce for checking overlaps

        Random random = new Random();
        int result = random.nextInt(2) + 2;//creates random number from 2-3 for declaring new spawned imageViews
        if(ArrayX.contains(resultx) && ArrayY.contains(resulty)){// if x and y coordinate are exact to another imageview
            resultx *= 0.5;
            resulty *= 0.5;//moves x and y coordinate of imageview
        }
        ArrayX.add(Integer.valueOf(resultx)); //adds to data structure of X
        ArrayY.add(Integer.valueOf(resulty)); //adds to data structure of Y
        int finalResultx = resultx;
        int finalResulty = resulty;
        Three.setOnMouseClicked(new EventHandler<MouseEvent>() {// when image is clicked
            @Override
            public void handle(MouseEvent t) {

                playingField.getChildren().remove(Three);//remove from playing area
                ArrayX.remove(ArrayX.indexOf(finalResultx )); //remove x coordinates because it is removed
               ArrayY.remove(ArrayY.indexOf(finalResulty));  //remove y coordinates because it is removed
                count += 1;//increase count
                for(int i = 0; i < result; i++){ //recursive call of n-1 hydra head which spawns random 2-3 range for loop

                    HeadSize2();
                }
            }
        });

        playingField.getChildren().add(Three);//add Image View
    }
    public void HeadSize4(){
        Random randomPos = new Random();//random called for x and y coordinates
        ImageView Four = new ImageView(hydra4);//set an ImageView to hydra four image
        Four.setFitHeight(40);
        Four.setFitWidth(40);//sets hydra image size to 40 x 40
        Four.setLayoutX(randomPos.nextInt(760));//generates imageview randomly on x axis from 0 - 780
        int resultx = (int)Four.getLayoutX();//retrieve x coordinate produce for checking overlaps

        Four.setLayoutY(randomPos.nextInt(650));//generates imageview randomly on y axis from 0 - 650
        int resulty = (int)Four.getLayoutY();//retrieve y coordinate produce for checking overlaps

        Random random = new Random();
        int result = random.nextInt(2) + 2;//creates random number from 2-3 for declaring new spawned imageViews
        if(ArrayX.contains(resultx) && ArrayY.contains(resulty)){// if x and y coordinate are exact to another imageview
            resultx *= 0.5;
            resulty *= 0.5;//moves x and y coordinate of imageview
        }
        ArrayX.add(Integer.valueOf(resultx)); //adds to data structure of X
        ArrayY.add(Integer.valueOf(resulty)); //adds to data structure of Y
        int finalResultx = resultx;
        int finalResulty = resulty;
        Four.setOnMouseClicked(new EventHandler<MouseEvent>() {// when image is clicked

            @Override
            public void handle(MouseEvent t) {

                playingField.getChildren().remove(Four);//remove from playing area
                ArrayX.remove(ArrayX.indexOf(finalResultx)); //remove x coordinates because it is removed
                ArrayY.remove(ArrayY.indexOf(finalResulty));//remove y coordinates because it is removed
                count += 1;//increase count
                for(int i = 0; i <result; i++){//recursive call of n-1 hydra head which spawns random 2-3 range for loop

                    HeadSize3();
                }
            }
        });

        playingField.getChildren().add(Four);//add Image View
    }
    public void HeadSize5(){
        Random randomPos = new Random();//random called for x and y coordinates
        ImageView Five = new ImageView(hydra5);//set an ImageView to hydra five image
        Five.setFitHeight(40);
        Five.setFitWidth(40);//sets hydra image size to 40 x 40
        Five.setLayoutX(randomPos.nextInt(760));//generates imageview randomly on x axis from 0 - 780
        int resultx = (int)Five.getLayoutX();//retrieve x coordinate produce for checking overlaps

        Five.setLayoutY(randomPos.nextInt(650));//generates imageview randomly on y axis from 0 - 650
        int resulty = (int)Five.getLayoutY();//retrieve y coordinate produce for checking overlaps

        Random random = new Random();
        int result = random.nextInt(2) + 2;//creates random number from 2-3 for declaring new spawned imageViews
        if(ArrayX.contains(resultx) && ArrayY.contains(resulty)){// if x and y coordinate are exact to another imageview
            resultx *= 0.5;
            resulty *= 0.5;//moves x and y coordinate of imageview
        }
        ArrayX.add(Integer.valueOf(resultx)); //adds to data structure of X
        ArrayY.add(Integer.valueOf(resulty)); //adds to data structure of Y
        int finalResultx = resultx;
        int finalResulty = resulty;
        Five.setOnMouseClicked(new EventHandler<MouseEvent>() {// when image is clicked
            @Override
            public void handle(MouseEvent t) {

                playingField.getChildren().remove(Five);//remove from playing area
                ArrayX.remove(ArrayX.indexOf(finalResultx));  //remove x coordinates because it is removed
                ArrayY.remove(ArrayY.indexOf(finalResulty)); //remove y coordinates because it is removed
                count += 1;//increase count
                for(int i = 0; i < result; i++){//recursive call of n-1 hydra head which spawns random 2-3 range for loop

                    HeadSize4();
                }
            }
        });

        playingField.getChildren().add(Five);//add Image View
    }
    public void HeadSize6(){
        Random randomPos = new Random();//random called for x and y coordinates
        ImageView Six = new ImageView(hydra6);//set an ImageView to hydra six image
        Six.setFitHeight(40);
        Six.setFitWidth(40);//sets hydra image size to 40 x 40
        Six.setLayoutX(randomPos.nextInt(760));//generates imageview randomly on x axis from 0 - 780
        int resultx = (int)Six.getLayoutX();//retrieve x coordinate produce for checking overlaps

        Six.setLayoutY(randomPos.nextInt(650));//generates imageview randomly on y axis from 0 - 650
        int resulty = (int)Six.getLayoutY();//retrieve y coordinate produce for checking overlaps

        Random random = new Random();
        int result = random.nextInt(2) + 2; //creates random number from 2-3 for declaring new spawned imageViews
        if(ArrayX.contains(resultx) && ArrayY.contains(resulty)){// if x and y coordinate are exact to another imageview
            resultx *= 0.5;
            resulty *= 0.5;//moves x and y coordinate of imageview
        }
        ArrayX.add(Integer.valueOf(resultx));//adds to data structure of X
        ArrayY.add(Integer.valueOf(resulty));//adds to data structure of Y
        int finalResultx = resultx;
        int finalResulty = resulty;
        Six.setOnMouseClicked(new EventHandler<MouseEvent>() {// when image is clicked
            @Override
            public void handle(MouseEvent t) {

                playingField.getChildren().remove(Six);//remove from playing area
                ArrayX.remove(ArrayX.indexOf(finalResultx)); //remove x coordinates because it is removed
                ArrayY.remove(ArrayY.indexOf(finalResulty));//remove y coordinates because it is removed
                count += 1;//increase count
                for(int i = 0; i < result; i++){//recursive call of n-1 hydra head which spawns random 2-3 range for loop

                    HeadSize5();
                }
            }
        });

        playingField.getChildren().add(Six);//add Image View
    }


    public void resetFunction(){ //when reset is called
        slider.setValue(4); //set the slider back to default value 4
        playButton.setDisable(false); //activate play button again
        slider.setDisable(false); //activate slider
        playingField.getChildren().clear(); //clear all hydra heads and label if there are any
        playingField.getChildren().add(WonLabel); //puts won label back to set for winning score
        WonLabel.setDisable(true); //hide won label
        WonLabel.setText("");
        count = 0; //set score back to 0 because ame reset

    }




}