module com.example.hyrdagame {
    requires javafx.controls;
    requires javafx.fxml;
    requires java.desktop;


    opens com.example.hyrdagame to javafx.fxml;
    exports com.example.hyrdagame;
}